#include "Config.h"

#include "SDK/Files/Paths.h"
#include "SDK/Logger/Logger.h"

#include <cstdio>
#include <fstream>
#include <map>

namespace
{
    constexpr const char* ConfigFileName = "anchousechanger.cfg";

    std::map<std::string, std::string> Values;

    void Save()
    {
        std::string FilePath = Paths::Resolve(ConfigFileName);

        // Do not leave an empty file behind: without settings there is no
        // config at all.
        if (Values.empty())
        {
            if (std::remove(FilePath.c_str()) == 0)
                Log("Config %s removed (no settings left)", FilePath.c_str());
            return;
        }

        std::ofstream File(FilePath, std::ios::trunc);
        if (!File)
        {
            LogE("Failed to write %s", FilePath.c_str());
            return;
        }

        for (const auto& [Key, Value] : Values)
            File << Key << '=' << Value << '\n';
    }
}

bool Config::Init()
{
    Values.clear();

    std::string FilePath = Paths::Resolve(ConfigFileName);
    std::ifstream File(FilePath);
    if (!File)
    {
        Log("Config %s not found, starting empty", FilePath.c_str());
        return true;
    }

    bool DroppedSkinData = false;
    std::string Line;
    while (std::getline(File, Line))
    {
        if (!Line.empty() && Line.back() == '\r')
            Line.pop_back();

        std::size_t Separator = Line.find('=');
        if (Separator == std::string::npos || Separator == 0)
            continue;

        std::string Key = Line.substr(0, Separator);
        // Selected loadouts now live in anchousechanger.sets. Remove the old
        // config-based skin keys so they cannot override that file.
        if (Key == "skin.items" || Key == "skin.unusual")
        {
            DroppedSkinData = true;
            continue;
        }

        Values[Key] = Line.substr(Separator + 1);
    }
    File.close();

    if (DroppedSkinData)
    {
        Log("Config: dropped persisted skin data (%zu settings left)", Values.size());
        Save();
    }

    Log("Config %s loaded, %zu keys", FilePath.c_str(), Values.size());
    return true;
}

std::string Config::Get(const char* Key)
{
    auto Entry = Values.find(Key);
    return Entry != Values.end() ? Entry->second : std::string();
}

void Config::Set(const char* Key, const std::string& Value)
{
    if (Value.empty())
        Values.erase(Key);
    else
        Values[Key] = Value;
    Save();
}
