#include "RunFrameHook.h"

#include "Changer/Match/EmblemEffect.h"
#include "Changer/Match/ImpactEffects.h"
#include "Changer/Inventory/InventorySync.h"
#include "Changer/Inventory/SkinPersistence.h"
#include "Changer/Match/NetSkins.h"
#include "Changer/Ui/UnusualSettings.h"
#include "Hooks/GcRecvHook.h"
#include "Misc/Patterns.h"
#include "SDK/Logger/Logger.h"
#include "SDK/Memory/Memory.h"
#include "SDK/Panorama/Panel.h"
#include "SDK/V8/V8Dumper.h"

#include <MinHook.h>

#include <cstdint>
#include <string>
#include <unordered_set>
#include <vector>

namespace
{
    void (*Original)(void*) = nullptr;
    bool Dumped = false;
    unsigned PopupCheckFrame = 0;
    std::unordered_set<std::string> LoggedPopups;

    void SuppressReceivedPopup()
    {
        // The catalog is delivered as one large subscription. Dota queues a
        // "new item" popup for every fake item, which would otherwise block
        // the dashboard behind twelve thousand dialogs. Hiding the popup root
        // is enough; its modal backdrop and hit-testing collapse with it.
        if (++PopupCheckFrame % 60 != 0)
            return;

        Panorama::Scope Scope;
        if (!Scope.IsValid())
            return;

        Panel Root = Panel::Root();
        if (!Root.IsValid())
        {
            Root.Release();
            return;
        }

        std::vector<Panel> Popups = Root.FindChildrenWithClass("PopupItemReceived");
        for (Panel& Popup : Popups)
        {
            if (!Popup.IsValid())
            {
                Popup.Release();
                continue;
            }

            const std::string Id = Popup.Id();
            if (LoggedPopups.insert(Id).second)
                Log("UI: hiding received-items popup id=\"%s\" class=PopupItemReceived", Id.c_str());
            Popup.SetVisible(false);
            Popup.Release();
        }

        // Some game versions use an id but omit the class (or use a different
        // popup skin). Cover the known root id as a fallback.
        Panel ItemReceived = Root.FindChildTraverse("ItemReceived");
        if (ItemReceived.IsValid())
        {
            if (LoggedPopups.insert("ItemReceived").second)
                Log("UI: hiding received-items popup id=\"ItemReceived\"");
            ItemReceived.SetVisible(false);
        }
        ItemReceived.Release();

        Root.Release();
    }

    void Detour(void* Engine)
    {
        InventorySync::Update();
        SkinPersistence::Update();
        GcRecvHook::Update();
        Original(Engine);

        if (!Dumped)
        {
            Dumped = true;
            V8Dumper::Run();
        }

        NetSkins::Update();
        EmblemEffect::Update();
        ImpactEffects::Update();
        UnusualSettings::Update();
        SuppressReceivedPopup();
    }
}

bool RunFrameHook::Install()
{
    std::uintptr_t Target = Memory::FindPattern("panorama.dll", Patterns::RunFrame);
    if (!Target)
    {
        LogE("RunFrame pattern not found");
        return false;
    }

    MH_STATUS Status = MH_Initialize();
    if (Status != MH_OK && Status != MH_ERROR_ALREADY_INITIALIZED)
    {
        LogE("MinHook init failed: %s", MH_StatusToString(Status));
        return false;
    }

    auto* TargetFn = reinterpret_cast<void*>(Target);
    Status = MH_CreateHook(TargetFn, reinterpret_cast<void*>(Detour), reinterpret_cast<void**>(&Original));
    if (Status == MH_OK)
        Status = MH_EnableHook(TargetFn);

    if (Status != MH_OK)
    {
        LogE("RunFrame hook failed: %s", MH_StatusToString(Status));
        return false;
    }

    Log("RunFrame %#llx", static_cast<unsigned long long>(Target));
    return true;
}
