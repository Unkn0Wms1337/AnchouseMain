#include "InventorySync.h"

#include "Changer/Inventory/FakeItems.h"
#include "Changer/Gc/GcEmulator.h"
#include "Changer/Gc/ItemGrant.h"
#include "Changer/Inventory/GemCatalog.h"
#include "Changer/Items/ItemSockets.h"
#include "Changer/Gc/ItemStyles.h"
#include "Changer/Inventory/RealItems.h"
#include "Changer/Inventory/SkinPersistence.h"
#include "Changer/Unusual/UnusualStore.h"
#include "Hooks/GcRecvHook.h"
#include "Hooks/GcSendHook.h"
#include "SDK/Config/Config.h"
#include "SDK/Econ/CDOTAInventoryManager.h"
#include "SDK/Econ/CDOTAPlayerInventory.h"
#include "SDK/Econ/C_EconItemView.h"
#include "SDK/Econ/CEconItemSchema.h"
#include "SDK/GC/CGCClient.h"
#include "SDK/Logger/Logger.h"
#include "SDK/SteamAPI/ISteamUser.h"

#include "gcsdk_gcmessages.pb.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdlib>
#include <iterator>
#include <mutex>
#include <set>
#include <string>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>
#include <windows.h>

namespace
{
    constexpr int SoTypeEconItem = 1;
    constexpr std::uint32_t SoOwnerTypeUser = 1;
    constexpr std::uint32_t EMsgSoCreate = 21;
    constexpr std::uint32_t EMsgSoUpdate = 22;
    constexpr std::uint32_t EMsgSoDestroy = 23;
    constexpr std::uint32_t EMsgSoCacheSubscribed = 24;
    constexpr std::uint32_t EMsgSoUpdateMultiple = 26;
    constexpr std::uint32_t EMsgSoSubscriptionCheck = 27;
    constexpr std::uint32_t EMsgSoSubscriptionRefresh = 28;
    constexpr std::uint32_t EMsgForceSoCacheResend = 7037;
    constexpr std::size_t DefaultGrantChunk = 256;
    constexpr long long DefaultGrantWaitMs = 12000;
    constexpr long long RefreshRetryMs = 4000;
    constexpr long long RefreshFirstMs = 1500;
    constexpr int RefreshMaxAttempts = 5;
    constexpr long long ProbeTimesMs[] = {4000, 6500};
    constexpr int ProbeCount = static_cast<int>(sizeof(ProbeTimesMs) / sizeof(ProbeTimesMs[0]));
    constexpr long long SnapshotRetryTimesMs[] = {4000, 10000, 16000};
    constexpr int SnapshotRetryCount =
        static_cast<int>(sizeof(SnapshotRetryTimesMs) / sizeof(SnapshotRetryTimesMs[0]));
    constexpr int WatchdogSeconds = 15;
    constexpr long long StagedHoldMs = 3000;
    // Wait in wall-clock time, not frames: after the + button removal the
    // Panorama frame rate became high enough that 30 frames could elapse
    // before the client finished processing the first 12k-item subscription.
    // Replaying the held cache message that early could freeze the game.
    constexpr long long HeldWaitMs = 2000;
    constexpr long long HeldUnknownMs = 6000;

    using Clock = std::chrono::steady_clock;
    using InventorySync::Action;

    long long Elapsed(Clock::time_point Start)
    {
        return std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - Start).count();
    }

    bool LoaderInjected()
    {
        // Auto-grant is armed only by loader.exe. The loader writes a
        // per-target marker next to the DLL immediately before injection;
        // the marker is consumed here and expires after two minutes.
        HMODULE Module = nullptr;
        if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                                reinterpret_cast<LPCWSTR>(&LoaderInjected), &Module))
            return false;

        wchar_t ModulePath[MAX_PATH] = {};
        const DWORD Length = GetModuleFileNameW(Module, ModulePath, MAX_PATH);
        if (Length == 0 || Length >= MAX_PATH)
            return false;

        std::wstring Marker(ModulePath, Length);
        const std::size_t Slash = Marker.find_last_of(L"\\/");
        if (Slash == std::wstring::npos)
            return false;
        Marker.resize(Slash + 1);
        Marker += L"anchousechanger.loader.";
        Marker += std::to_wstring(GetCurrentProcessId());

        WIN32_FILE_ATTRIBUTE_DATA Attributes = {};
        if (!GetFileAttributesExW(Marker.c_str(), GetFileExInfoStandard, &Attributes))
        {
            Log("AutoGrant: disabled (no loader marker for pid %lu)", GetCurrentProcessId());
            return false;
        }

        ULARGE_INTEGER MarkerTime = {};
        MarkerTime.LowPart = Attributes.ftLastWriteTime.dwLowDateTime;
        MarkerTime.HighPart = Attributes.ftLastWriteTime.dwHighDateTime;

        FILETIME NowFileTime = {};
        GetSystemTimeAsFileTime(&NowFileTime);
        ULARGE_INTEGER Now = {};
        Now.LowPart = NowFileTime.dwLowDateTime;
        Now.HighPart = NowFileTime.dwHighDateTime;

        constexpr ULONGLONG MaxAge100ns = 120ull * 10'000'000ull;
        const bool IsFile = (Attributes.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0;
        const bool Fresh = IsFile && Now.QuadPart >= MarkerTime.QuadPart &&
                           Now.QuadPart - MarkerTime.QuadPart <= MaxAge100ns;
        DeleteFileW(Marker.c_str());

        Log("AutoGrant: %s by loader marker (pid=%lu)", Fresh ? "enabled" : "disabled (expired)", GetCurrentProcessId());
        return Fresh;
    }

    bool AutoGrant()
    {
        static const bool Enabled = [] {
            return Config::Get("skin.autogrant") != "0" && LoaderInjected();
        }();
        return Enabled;
    }

    std::size_t GrantChunk()
    {
        static const std::size_t Chunk = [] {
            std::string Value = Config::Get("skin.grant.chunk");
            if (Value.empty())
                return DefaultGrantChunk;
            long long Parsed = std::strtoll(Value.c_str(), nullptr, 10);
            return Parsed > 0 ? static_cast<std::size_t>(Parsed) : std::size_t(0);
        }();
        return Chunk;
    }

    bool ProbesEnabled()
    {
        static const bool Enabled = [] {
            return Config::Get("skin.grant.probe") != "0";
        }();
        return Enabled;
    }

    bool SnapshotAppend()
    {
        static const bool Enabled = [] {
            return Config::Get("skin.grant.snapshot") != "0";
        }();
        return Enabled;
    }

    long long GrantWaitMs()
    {
        static const long long Wait = [] {
            std::string Value = Config::Get("skin.grant.wait");
            if (Value.empty())
                return DefaultGrantWaitMs;
            long long Parsed = std::strtoll(Value.c_str(), nullptr, 10);
            return Parsed >= 0 ? Parsed * 1000 : DefaultGrantWaitMs;
        }();
        return Wait;
    }

    std::mutex ShownMutex;
    std::unordered_map<std::uint64_t, std::string> Shown;
    bool Started = false;
    bool Subscribed = false;
    bool Prepared = false;
    bool WatchdogStarted = false;

    bool GrantArmed = false;
    bool Streaming = false;
    bool SnapshotTaken = false;
    bool ProbesDone = false;
    int SnapshotRetryStage = 0;
    std::string FullSnapshotBody;
    std::uint64_t FullSnapshotVersion = 0;
    Clock::time_point SnapshotTakenAt;
    int ProbeStage = 0;
    long long NextRefreshMs = RefreshFirstMs;
    int RefreshAttempts = 0;
    Clock::time_point GrantStart;

    std::vector<std::uint64_t> DeliveryQueue;
    std::size_t DeliveryIndex = 0;
    std::atomic<std::uint64_t> DeliveredCount{0};
    std::atomic<std::uint64_t> DeliveryTotal{0};
    std::atomic<std::uint64_t> FrameCount{0};
    std::atomic<int> GrantMode{0};

    std::uint64_t ServedOwner = 0;
    std::uint64_t ServedVersion = 0;
    bool HaveServed = false;
    std::uint64_t ProbeId = 0;
    std::atomic<int> CacheState{0};
    Clock::time_point HeldSeenAt;
    bool HeldTimerActive = false;
    bool SeenPresent = false;
    int MissingProbes = 0;

    bool Staged = false;
    std::uint64_t StagedOwner = 0;
    std::uint64_t StagedVersion = 0;
    Clock::time_point StagedAt;

    std::string SnapshotWithVersion(std::uint64_t NewVersion)
    {
        if (FullSnapshotBody.empty())
            return {};
        CMsgSOCacheSubscribed Message;
        if (!Message.ParseFromString(FullSnapshotBody))
            return {};
        Message.set_version(NewVersion);
        return Message.SerializeAsString();
    }

    bool IsLocalOwner(const CMsgSOIDOwner& Owner)
    {
        ISteamUser* User = ISteamUser::Get();
        return Owner.type() == SoOwnerTypeUser && User && Owner.id() == User->GetSteamID();
    }

    std::set<std::uint32_t> OccupiedSlots()
    {
        std::set<std::uint32_t> Occupied;
        for (const CSOEconItem& Item : FakeItems::EquippedAll())
            for (const auto& State : Item.equipped_state())
                Occupied.insert((State.new_slot() << 16) | (State.new_class() & 0xFFFF));
        return Occupied;
    }

    CSOEconItem Desired(const CSOEconItem& Pristine, const std::set<std::uint32_t>& Occupied)
    {
        CSOEconItem Out = Pristine;
        auto* States = Out.mutable_equipped_state();
        for (int Index = States->size() - 1; Index >= 0; --Index)
        {
            const auto& State = States->Get(Index);
            if (Occupied.count((State.new_slot() << 16) | (State.new_class() & 0xFFFF)))
                States->DeleteSubrange(Index, 1);
        }
        if (int Effect = UnusualStore::Get(Pristine.id()))
            ItemSockets::SetUnusual(Out, Effect, Pristine.quality());
        return Out;
    }

    bool ReplaceReal(std::string& Data, const std::set<std::uint32_t>& Occupied)
    {
        CSOEconItem Item;
        if (!Item.ParseFromString(Data) || !Item.id() || FakeItems::IsFake(Item.id()))
            return false;
        RealItems::Set(Item);
        std::string Out = Desired(Item, Occupied).SerializeAsString();
        {
            std::lock_guard<std::mutex> Lock(ShownMutex);
            Shown[Item.id()] = Out;
        }
        if (Out == Data)
            return false;
        Data = std::move(Out);
        return true;
    }

    void Forget(const std::string& Data)
    {
        CSOEconItem Item;
        if (!Item.ParseFromString(Data) || !Item.id())
            return;
        RealItems::Remove(Item.id());
        std::lock_guard<std::mutex> Lock(ShownMutex);
        Shown.erase(Item.id());
    }

    void PrepareFakes()
    {
        auto Start = Clock::now();

        GemCatalog::EnsureGranted();

        ISteamUser* User = ISteamUser::Get();
        std::uint32_t AccountId = User ? User->AccountId() : 0;

        std::vector<CSOEconItem> Added;
        if (!Prepared)
            Added = ItemGrant::MissingWearables();

        for (CSOEconItem& Item : Added)
        {
            if (AccountId)
                Item.set_account_id(AccountId);
            ItemStyles::UnlockAll(Item);
            int Effect = UnusualStore::Get(Item.id());
            if (Effect || ItemSockets::FindGem(Item, ItemSockets::UnusualGemDef))
                ItemSockets::SetUnusual(Item, Effect, ItemSockets::QualityUnique);
        }

        std::size_t New = Added.size();

        if (AccountId)
            FakeItems::ForEach([&](CSOEconItem& Item) {
                if (Item.account_id() != AccountId)
                {
                    Item.set_account_id(AccountId);
                    Added.push_back(Item);
                }
            });

        if (!Added.empty())
            FakeItems::Store(Added);

        SkinPersistence::Apply();

        Prepared = true;
        Log("Grant: prepared, %zu new items, %lld ms", New, Elapsed(Start));
    }

    std::size_t CountRealItems(const CMsgSOCacheSubscribed& Message)
    {
        std::size_t Total = 0;
        for (const auto& Type : Message.objects())
            if (Type.type_id() == SoTypeEconItem)
                Total += static_cast<std::size_t>(Type.object_data_size());
        return Total;
    }

    std::size_t AppendFakes(CMsgSOCacheSubscribed& Message)
    {
        if (!Prepared)
            PrepareFakes();

        decltype(Message.add_objects()) Group = nullptr;
        for (auto& Type : *Message.mutable_objects())
        {
            if (Type.type_id() == SoTypeEconItem)
            {
                Group = &Type;
                break;
            }
        }
        if (!Group)
        {
            Group = Message.add_objects();
            Group->set_type_id(SoTypeEconItem);
        }

        std::size_t Appended = 0;
        for (std::uint64_t Id : FakeItems::Ids())
        {
            if (auto Item = FakeItems::Find(Id))
            {
                Group->add_object_data(Item->SerializeAsString());
                ++Appended;
            }
        }
        return Appended;
    }

    void QueueDelivery()
    {
        DeliveryQueue = FakeItems::Ids();
        DeliveryIndex = 0;
        DeliveredCount = 0;
        DeliveryTotal = DeliveryQueue.size();
        Log("Grant: queued %zu items, chunk %zu", DeliveryQueue.size(), GrantChunk());
    }

    void StreamChunk()
    {
        if (DeliveryIndex >= DeliveryQueue.size())
            return;
        if (GcRecvHook::Queued() != 0)
            return;

        std::size_t Chunk = GrantChunk();
        std::size_t Remaining = DeliveryQueue.size() - DeliveryIndex;
        std::size_t Count = Chunk ? (std::min)(Chunk, Remaining) : Remaining;

        std::vector<CSOEconItem> Batch;
        Batch.reserve(Count);
        for (std::size_t Index = DeliveryIndex; Index < DeliveryIndex + Count; ++Index)
        {
            if (auto Item = FakeItems::Find(DeliveryQueue[Index]))
                Batch.push_back(std::move(*Item));
        }
        DeliveryIndex += Count;

        if (!Batch.empty())
            GcEmulator::SendItems(Batch, {});

        std::uint64_t Sent = DeliveredCount.fetch_add(Batch.size()) + Batch.size();
        Log("Grant: streamed %llu/%llu (%zu items, %lld ms)",
            static_cast<unsigned long long>(Sent),
            static_cast<unsigned long long>(DeliveryTotal.load()), Batch.size(), Elapsed(GrantStart));
    }

    void FireProbe(int Index)
    {
        ISteamUser* User = ISteamUser::Get();
        std::uint64_t OwnerId = User ? User->GetSteamID() : 0;

        switch (Index)
        {
        case 0:
        {
            CMsgSOCacheSubscriptionCheck Check;
            Check.set_version(~std::uint64_t(0));
            Check.mutable_owner_soid()->set_type(SoOwnerTypeUser);
            Check.mutable_owner_soid()->set_id(OwnerId);
            GcEmulator::PushMessage(EMsgSoSubscriptionCheck, Check.SerializeAsString());
            Log("Grant: probe check -> client (EMsg %u)", EMsgSoSubscriptionCheck);
            break;
        }
        case 1:
            GcEmulator::PushMessage(EMsgForceSoCacheResend, std::string());
            Log("Grant: probe resend -> client (EMsg %u)", EMsgForceSoCacheResend);
            break;
        }
    }

    void TryRefreshGc(long long ElapsedMs)
    {
        if (RefreshAttempts >= RefreshMaxAttempts || ElapsedMs < NextRefreshMs)
            return;

        ISteamUser* User = ISteamUser::Get();
        CMsgSOCacheSubscriptionRefresh Refresh;
        Refresh.mutable_owner_soid()->set_type(SoOwnerTypeUser);
        Refresh.mutable_owner_soid()->set_id(User ? User->GetSteamID() : 0);

        if (!GcSendHook::Post(EMsgSoSubscriptionRefresh, Refresh.SerializeAsString()))
            return;

        ++RefreshAttempts;
        NextRefreshMs = ElapsedMs + RefreshRetryMs;
        Log("Grant: refresh -> gc (EMsg %u, attempt %d/%d)",
            EMsgSoSubscriptionRefresh, RefreshAttempts, RefreshMaxAttempts);
    }

    void AdvanceGrant()
    {
        if (SnapshotTaken)
        {
            // A large cache subscription can race the client's initial
            // inventory setup. If the probe still cannot find the catalog a
            // few seconds after the complete snapshot was served, push that
            // same complete snapshot once more. Never fall back to streaming
            // thousands of individual items here: that is what caused the
            // multi-minute stalls and unresponsive UI.
            const long long SinceSnapshot = Elapsed(SnapshotTakenAt);
            while (SnapshotRetryStage < SnapshotRetryCount &&
                   SinceSnapshot >= SnapshotRetryTimesMs[SnapshotRetryStage])
            {
                if (FullSnapshotBody.empty() || CacheState.load() != 2)
                    break;

                const int Stage = SnapshotRetryStage++;
                const std::uint64_t RetryVersion = FullSnapshotVersion;
                std::string Retry = SnapshotWithVersion(RetryVersion);
                if (!Retry.empty())
                {
                    GcEmulator::PushMessage(EMsgSoCacheSubscribed, Retry);
                    Log("Grant: cache still empty, pushed complete snapshot again (%zu bytes, version %llu, retry %d/%d)",
                        Retry.size(), static_cast<unsigned long long>(RetryVersion), Stage + 1, SnapshotRetryCount);
                }
                break;
            }
            return;
        }

        if (!GrantArmed)
        {
            GrantArmed = true;
            GrantStart = Clock::now();
            QueueDelivery();
        }

        long long ElapsedMs = Elapsed(GrantStart);

        if (ProbesEnabled())
        {
            TryRefreshGc(ElapsedMs);

            if (!ProbesDone)
            {
                while (ProbeStage < ProbeCount && ElapsedMs >= ProbeTimesMs[ProbeStage])
                    FireProbe(ProbeStage++);
                ProbesDone = ProbeStage >= ProbeCount;
            }

            if (!ProbesDone && ElapsedMs < GrantWaitMs())
                return;
        }

        if (!Streaming && ElapsedMs >= GrantWaitMs())
        {
            Streaming = true;
            GrantMode.store(1);
            Log("Grant: no snapshot after %lld ms, streaming %zu items by %zu",
                ElapsedMs, DeliveryQueue.size(), GrantChunk());
        }

        if (Streaming)
            StreamChunk();
    }

    void StartWatchdog()
    {
        if (WatchdogStarted)
            return;
        WatchdogStarted = true;
        std::thread([] {
            for (;;)
            {
                std::this_thread::sleep_for(std::chrono::seconds(WatchdogSeconds));
                Log("Watchdog: frames=%llu queued=%zu delivery=%llu/%llu mode=%d",
                    static_cast<unsigned long long>(FrameCount.load()), GcRecvHook::Queued(),
                    static_cast<unsigned long long>(DeliveredCount.load()),
                    static_cast<unsigned long long>(DeliveryTotal.load()), GrantMode.load());
            }
        }).detach();
    }

    void ProbeCache()
    {
        if (!ProbeId)
        {
            std::vector<std::uint64_t> Ids = FakeItems::Ids();
            if (Ids.empty())
                return;
            ProbeId = Ids.front();
        }

        CDOTAInventoryManager* Manager = CDOTAInventoryManager::Get();
        CDOTAPlayerInventory* Local = Manager ? Manager->LocalInventory() : nullptr;
        if (!Local)
            return;

        C_EconItemView* View = Local->FindItem(ProbeId);
        const int State = View ? 1 : 2;
        const int Previous = CacheState.exchange(State);
        if (Previous != State)
            Log("Cache probe: fake %#llx %s", static_cast<unsigned long long>(ProbeId),
                View ? "present" : "missing");

        if (View)
        {
            SeenPresent = true;
            MissingProbes = 0;
        }
        else if (SeenPresent)
        {
            ++MissingProbes;
        }
    }

    void BeginStream(const char* Reason, int Mode)
    {
        SnapshotTaken = false;
        Streaming = true;
        GrantArmed = true;
        GrantStart = Clock::now();
        ProbesDone = true;
        GrantMode.store(Mode);
        QueueDelivery();
        Log("Grant: %s, streaming %zu items", Reason, DeliveryQueue.size());
    }

    void WatchHeld()
    {
        if (!GcRecvHook::HeldPending())
        {
            HeldTimerActive = false;
            return;
        }

        if (!HeldTimerActive)
        {
            HeldTimerActive = true;
            HeldSeenAt = Clock::now();
        }
        const long long Waited = Elapsed(HeldSeenAt);
        if (Waited < HeldWaitMs)
            return;

        const int State = CacheState.load();
        if (State == 1)
        {
            GcRecvHook::DiscardHeld();
            Log("Subscribe: held duplicate dropped, cache intact after %lld ms", Waited);
            HeldTimerActive = false;
        }
        else if (State == 2)
        {
            if (GcRecvHook::ReplayHeld())
            {
                // Do not start the slow per-item stream here. The replay is
                // only a last-resort empty cache; wait for the complete GC
                // snapshot and merge the catalog into that single message.
                Log("Subscribe: cache empty, replayed held subscribe after %lld ms", Waited);
                HeldTimerActive = false;
            }
        }
        else if (Waited >= HeldUnknownMs)
        {
            GcRecvHook::DiscardHeld();
            Log("Subscribe: held duplicate dropped, cache unknown after %lld ms", Waited);
            HeldTimerActive = false;
        }
    }

    void CheckStagedSubscription()
    {
        if (!Staged)
            return;

        const long long Age = Elapsed(StagedAt);
        if (Age < StagedHoldMs)
            return;

        const std::uint64_t OwnerId = StagedOwner;
        const std::uint64_t Version = StagedVersion;
        Staged = false;
        StagedOwner = 0;
        StagedVersion = 0;

        if (!GcRecvHook::ReplayHeld())
        {
            Log("Subscribe: staged empty version %llu replay failed",
                static_cast<unsigned long long>(Version));
            return;
        }

        ServedOwner = OwnerId;
        ServedVersion = Version;
        HaveServed = true;
        CacheState.store(0);
        RealItems::Clear();
        {
            std::lock_guard<std::mutex> Lock(ShownMutex);
            Shown.clear();
        }
        Log("Subscribe: staged empty version %llu replayed after %lld ms",
            static_cast<unsigned long long>(Version), Age);

        // No complete subscription arrived. Let the normal grant loop deliver
        // the catalog as separate item updates after its usual wait; injecting
        // it into this empty cache would defeat the stale-view protection.
    }

    void OnUnusual(std::uint64_t ItemId, int Effect)
    {
        if (!FakeItems::IsFake(ItemId))
        {
            InventorySync::Refresh();
            return;
        }
        auto Item = FakeItems::Find(ItemId);
        if (!Item)
            return;
        ItemSockets::SetUnusual(*Item, Effect, ItemSockets::QualityUnique);
        FakeItems::Store(*Item);
        SkinPersistence::MarkItem(Item->id());
        GcEmulator::SendItems({}, {*Item});
    }

    void EnsureSubscribed()
    {
        if (Subscribed)
            return;
        Subscribed = true;
        UnusualStore::Subscribe(OnUnusual);
    }

    Action RewriteSubscribed(std::string& Body)
    {
        CMsgSOCacheSubscribed Message;
        if (!Message.ParseFromString(Body) || !IsLocalOwner(Message.owner_soid()))
            return Action::Pass;

        const std::uint64_t OwnerId = Message.owner_soid().id();
        const std::uint64_t Version = Message.version();
        const std::size_t Total = CountRealItems(Message);

        // An empty subscription is usually the client's stale or partial cache;
        // the authoritative one follows almost immediately. Appending the fake
        // catalog to the first message makes the client rebuild its inventory
        // twice, and the second rebuild leaves stale econ item views behind
        // (crash when a skin or persona is selected). Hold the empty message
        // briefly: a complete subscription supersedes it, otherwise replay it
        // with the fake catalog.
        if (!HaveServed && AutoGrant() && SnapshotAppend() && Total == 0)
        {
            if (Staged && OwnerId == StagedOwner && Version <= StagedVersion)
            {
                Log("Subscribe: empty version %llu <= staged %llu, held",
                    static_cast<unsigned long long>(Version), static_cast<unsigned long long>(StagedVersion));
                return Action::Drop;
            }

            const bool Replace = Staged;
            Staged = true;
            StagedOwner = OwnerId;
            StagedVersion = Version;
            StagedAt = Clock::now();
            Log("Subscribe: empty cache version %llu held, waiting for the complete cache%s",
                static_cast<unsigned long long>(Version), Replace ? " (replaced)" : "");
            return Replace ? Action::DropReplace : Action::Drop;
        }

        // A complete subscription supersedes a staged empty one.
        if (Staged && (Total > 0 || Version > StagedVersion))
        {
            GcRecvHook::DiscardHeld();
            Log("Subscribe: staged empty version %llu dropped, version %llu served",
                static_cast<unsigned long long>(StagedVersion), static_cast<unsigned long long>(Version));
            Staged = false;
            StagedOwner = 0;
            StagedVersion = 0;
        }

        if (HaveServed && OwnerId == ServedOwner && Version <= ServedVersion)
        {
            const int State = CacheState.load();

            // Never re-apply an empty stale subscription. Dota sends an old
            // empty cache message immediately after the real one; appending
            // the catalog to it (or replaying it) makes the client rebuild a
            // 12k-item inventory from scratch, drops the real items and can
            // freeze the main thread. The complete snapshot we already served
            // is authoritative; an empty duplicate is always safe to discard.
            if (Total == 0)
            {
                // The client can send a stale empty cache subscription after
                // it has already ignored the large complete one. Replacing the
                // empty body with the cached complete snapshot gives the client
                // the real items plus the catalog without a second empty-cache
                // rebuild. If the cache is known to be intact, the duplicate is
                // simply redundant.
                if (!FullSnapshotBody.empty() && State != 1)
                {
                    const std::uint64_t RetryVersion = FullSnapshotVersion;
                    Body = SnapshotWithVersion(RetryVersion);
                    if (!Body.empty())
                    {
                        Log("Subscribe: version %llu <= applied %llu, empty stale replaced with complete snapshot (version %llu)",
                            static_cast<unsigned long long>(Version), static_cast<unsigned long long>(ServedVersion),
                            static_cast<unsigned long long>(RetryVersion));
                        return Action::Changed;
                    }
                }
                Log("Subscribe: version %llu <= applied %llu, empty stale duplicate discarded",
                    static_cast<unsigned long long>(Version), static_cast<unsigned long long>(ServedVersion));
                return Action::Discard;
            }

            // A duplicate complete snapshot while the cache is still intact is
            // also redundant. Only re-apply a complete snapshot when the probe
            // says the client actually lost the cache.
            if (State != 2)
            {
                Log("Subscribe: version %llu <= applied %llu, cache %s, duplicate discarded",
                    static_cast<unsigned long long>(Version), static_cast<unsigned long long>(ServedVersion),
                    State == 1 ? "intact" : "unknown");
                return Action::Discard;
            }
            Log("Subscribe: version %llu <= applied %llu, cache empty, re-applied complete snapshot",
                static_cast<unsigned long long>(Version), static_cast<unsigned long long>(ServedVersion));
        }

        EnsureSubscribed();
        Started = true;
        ServedOwner = OwnerId;
        ServedVersion = Version;
        HaveServed = true;
        CacheState.store(0);
        RealItems::Clear();
        {
            std::lock_guard<std::mutex> Lock(ShownMutex);
            Shown.clear();
        }

        std::set<std::uint32_t> Occupied = OccupiedSlots();
        std::size_t Replaced = 0;
        for (auto& Type : *Message.mutable_objects())
        {
            if (Type.type_id() != SoTypeEconItem)
                continue;
            for (std::string& Data : *Type.mutable_object_data())
                Replaced += ReplaceReal(Data, Occupied) ? 1 : 0;
        }

        ProbesDone = true;

        std::size_t Appended = 0;
        if (AutoGrant() && SnapshotAppend())
        {
            Appended = AppendFakes(Message);
            if (Appended)
            {
                const std::uint64_t DeliveryVersion = Version;
                ServedVersion = DeliveryVersion;

                SnapshotTaken = true;
                SnapshotRetryStage = 0;
                SnapshotTakenAt = Clock::now();
                Streaming = false;
                GrantMode.store(2);
                DeliveryQueue.clear();
                DeliveryIndex = 0;
                DeliveredCount.store(Appended);
                DeliveryTotal.store(Appended);
                FullSnapshotVersion = DeliveryVersion;
                FullSnapshotBody = Message.SerializeAsString();
            }
        }

        if (!Replaced && !Appended)
        {
            Log("Subscribe: %zu real items, %zu replaced, ignored", Total, Replaced);
            return Action::Pass;
        }

        const std::size_t BeforeBytes = Body.size();
        Body = Message.SerializeAsString();
        Log("Subscribe: %zu real items, %zu replaced, %zu fakes added, %zu -> %zu bytes (served version %llu)",
            Total, Replaced, Appended, BeforeBytes, Body.size(),
            static_cast<unsigned long long>(ServedVersion));
        return Action::Changed;
    }

    bool RewriteMultiple(std::string& Body)
    {
        CMsgSOMultipleObjects Message;
        if (!Message.ParseFromString(Body) || !IsLocalOwner(Message.owner_soid()))
            return false;

        std::set<std::uint32_t> Occupied = OccupiedSlots();
        bool Changed = false;
        for (auto& Object : *Message.mutable_objects_added())
            if (Object.type_id() == SoTypeEconItem)
                Changed |= ReplaceReal(*Object.mutable_object_data(), Occupied);
        for (auto& Object : *Message.mutable_objects_modified())
            if (Object.type_id() == SoTypeEconItem)
                Changed |= ReplaceReal(*Object.mutable_object_data(), Occupied);
        for (const auto& Object : Message.objects_removed())
            if (Object.type_id() == SoTypeEconItem)
                Forget(Object.object_data());
        if (!Changed)
            return false;
        Body = Message.SerializeAsString();
        return true;
    }

    bool RewriteSingle(std::uint32_t EMsg, std::string& Body)
    {
        CMsgSOSingleObject Message;
        if (!Message.ParseFromString(Body) || !IsLocalOwner(Message.owner_soid()) || Message.type_id() != SoTypeEconItem)
            return false;
        if (EMsg == EMsgSoDestroy)
        {
            Forget(Message.object_data());
            return false;
        }
        if (!ReplaceReal(*Message.mutable_object_data(), OccupiedSlots()))
            return false;
        Body = Message.SerializeAsString();
        return true;
    }
}

void InventorySync::Update()
{
    FrameCount.fetch_add(1, std::memory_order_relaxed);
    const std::uint64_t Frame = FrameCount.load(std::memory_order_relaxed);
    StartWatchdog();

    ISteamUser* User = ISteamUser::Get();
    if (!Started)
    {
        if (!CGCClient::Get() || !User || !User->AccountId() || !CEconItemSchema::Get())
            return;
        Started = true;
        EnsureSubscribed();
        if (AutoGrant() && !Prepared)
            PrepareFakes();
        Refresh();
    }

    CheckStagedSubscription();

    if (HaveServed && Prepared)
    {
        if (Frame % 30 == 0)
        {
            ProbeCache();
            const bool Busy = Streaming && DeliveryIndex < DeliveryQueue.size();
            if (SeenPresent && MissingProbes >= 2 && !Busy && AutoGrant())
            {
                SeenPresent = false;
                MissingProbes = 0;
                BeginStream("cache lost", 4);
            }
        }
        WatchHeld();
    }

    if (AutoGrant())
        AdvanceGrant();
}

void InventorySync::Refresh()
{
    std::set<std::uint32_t> Occupied = OccupiedSlots();
    std::vector<CSOEconItem> Modified;
    RealItems::ForEach([&](const CSOEconItem& Pristine) {
        CSOEconItem Item = Desired(Pristine, Occupied);
        std::string Data = Item.SerializeAsString();
        std::lock_guard<std::mutex> Lock(ShownMutex);
        std::string& Current = Shown[Pristine.id()];
        if (Current == Data)
            return;
        Current = Data;
        Modified.push_back(Item);
    });

    if (Modified.empty())
        return;
    GcEmulator::SendItems({}, Modified);
}

InventorySync::Action InventorySync::Rewrite(std::uint32_t EMsg, std::string& Body)
{
    switch (EMsg)
    {
    case EMsgSoCacheSubscribed:
        return RewriteSubscribed(Body);
    case EMsgSoUpdateMultiple:
        return RewriteMultiple(Body) ? Action::Changed : Action::Pass;
    case EMsgSoCreate:
    case EMsgSoUpdate:
    case EMsgSoDestroy:
        return RewriteSingle(EMsg, Body) ? Action::Changed : Action::Pass;
    default:
        return Action::Pass;
    }
}
