#include "FakeItems.h"

#include <mutex>
#include <unordered_map>

namespace
{
    std::recursive_mutex                           ItemsMutex;
    std::unordered_map<std::uint64_t, CSOEconItem> Items;
    std::unordered_map<std::uint64_t, std::uint64_t> EquippedItems;
    std::vector<std::uint64_t>                      EquippedIds;

    void RebuildEquipped()
    {
        EquippedItems.clear();
        EquippedIds.clear();
        for (const auto& [Id, Item] : Items)
        {
            if (Item.equipped_state_size() == 0)
                continue;
            EquippedIds.push_back(Id);
            for (const auto& State : Item.equipped_state())
                EquippedItems[(static_cast<std::uint64_t>(State.new_class()) << 32) | State.new_slot()] = Id;
        }
    }
}

bool FakeItems::IsFake(std::uint64_t ItemId)
{
    return (ItemId >> 56) == (IdBase >> 56);
}

void FakeItems::Store(const CSOEconItem& Item)
{
    std::lock_guard<std::recursive_mutex> Lock(ItemsMutex);
    Items[Item.id()] = Item;
    RebuildEquipped();
}

void FakeItems::Store(const std::vector<CSOEconItem>& Batch)
{
    std::lock_guard<std::recursive_mutex> Lock(ItemsMutex);
    for (const CSOEconItem& Item : Batch)
        Items[Item.id()] = Item;
    RebuildEquipped();
}

std::optional<CSOEconItem> FakeItems::Find(std::uint64_t ItemId)
{
    std::lock_guard<std::recursive_mutex> Lock(ItemsMutex);
    auto It = Items.find(ItemId);
    if (It == Items.end())
        return std::nullopt;
    return It->second;
}

bool FakeItems::Has(std::uint64_t ItemId)
{
    std::lock_guard<std::recursive_mutex> Lock(ItemsMutex);
    return Items.find(ItemId) != Items.end();
}

std::uint64_t FakeItems::Equipped(std::uint32_t Class, std::uint32_t Slot)
{
    std::lock_guard<std::recursive_mutex> Lock(ItemsMutex);
    auto It = EquippedItems.find((static_cast<std::uint64_t>(Class) << 32) | Slot);
    return It == EquippedItems.end() ? 0 : It->second;
}

std::vector<CSOEconItem> FakeItems::EquippedAll()
{
    std::lock_guard<std::recursive_mutex> Lock(ItemsMutex);
    std::vector<CSOEconItem> Out;
    Out.reserve(EquippedIds.size());
    for (std::uint64_t Id : EquippedIds)
    {
        auto It = Items.find(Id);
        if (It != Items.end())
            Out.push_back(It->second);
    }
    return Out;
}

std::vector<CSOEconItem> FakeItems::All()
{
    std::lock_guard<std::recursive_mutex> Lock(ItemsMutex);
    std::vector<CSOEconItem> Out;
    Out.reserve(Items.size());
    for (const auto& [Id, Item] : Items)
        Out.push_back(Item);
    return Out;
}

std::vector<std::uint64_t> FakeItems::Ids()
{
    std::lock_guard<std::recursive_mutex> Lock(ItemsMutex);
    std::vector<std::uint64_t> Out;
    Out.reserve(Items.size());
    for (const auto& [Id, Item] : Items)
        Out.push_back(Id);
    return Out;
}

void FakeItems::ForEach(const std::function<void(CSOEconItem&)>& Visit)
{
    std::lock_guard<std::recursive_mutex> Lock(ItemsMutex);
    for (auto& [Id, Item] : Items)
        Visit(Item);
}
