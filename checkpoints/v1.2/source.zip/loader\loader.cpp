#include <windows.h>
#include <tlhelp32.h>
#include <shellapi.h>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <ctime>
#include <cwchar>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

namespace
{
    constexpr const wchar_t* ProcessName = L"dota2.exe";
    constexpr const wchar_t* DefaultDllName = L"anchousechanger.dll";
    constexpr const wchar_t* SteamLaunchUrl = L"steam://rungameid/570";

    std::wstring ExecutableDirectory()
    {
        wchar_t Path[MAX_PATH] = {};
        const DWORD Length = GetModuleFileNameW(nullptr, Path, MAX_PATH);
        if (Length == 0 || Length >= MAX_PATH)
            return {};

        std::wstring Result(Path, Length);
        const std::size_t Slash = Result.find_last_of(L"\\/");
        return Slash == std::wstring::npos ? std::wstring() : Result.substr(0, Slash + 1);
    }

    std::vector<DWORD> FindProcesses(const wchar_t* Name)
    {
        std::vector<DWORD> Result;
        const HANDLE Snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (Snapshot == INVALID_HANDLE_VALUE)
            return Result;

        PROCESSENTRY32W Entry = {};
        Entry.dwSize = sizeof(Entry);
        if (Process32FirstW(Snapshot, &Entry))
        {
            do
            {
                if (_wcsicmp(Entry.szExeFile, Name) == 0)
                    Result.push_back(Entry.th32ProcessID);
            } while (Process32NextW(Snapshot, &Entry));
        }

        CloseHandle(Snapshot);
        return Result;
    }

    bool HasModule(DWORD ProcessId, const wchar_t* Name)
    {
        const HANDLE Snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, ProcessId);
        if (Snapshot == INVALID_HANDLE_VALUE)
            return false;

        MODULEENTRY32W Entry = {};
        Entry.dwSize = sizeof(Entry);
        bool Found = false;
        if (Module32FirstW(Snapshot, &Entry))
        {
            do
            {
                if (_wcsicmp(Entry.szModule, Name) == 0)
                {
                    Found = true;
                    break;
                }
            } while (Module32NextW(Snapshot, &Entry));
        }

        CloseHandle(Snapshot);
        return Found;
    }

    bool WaitForGameModules(DWORD ProcessId)
    {
        // panorama.dll is the module the old loader raced against. The other
        // modules are initialized by SDK::Init() before the UI runs. Waiting for
        // them (instead of sleeping until the main menu is fully loaded) lets
        // the DLL see the client's first SOCache subscription, which is the
        // only subscription it can safely replace with the full catalog.
        constexpr const wchar_t* Required[] = {
            L"panorama.dll",
            L"v8.dll",
            L"schemasystem.dll",
            L"client.dll",
            L"resourcesystem.dll",
            L"steam_api64.dll",
        };

        const auto Deadline = std::chrono::steady_clock::now() + std::chrono::minutes(1);
        while (std::chrono::steady_clock::now() < Deadline)
        {
            bool Ready = true;
            for (const wchar_t* Module : Required)
            {
                if (!HasModule(ProcessId, Module))
                {
                    Ready = false;
                    break;
                }
            }
            if (Ready)
                return true;
            Sleep(200);
        }

        return false;
    }

    std::wstring ProcessImagePath(DWORD ProcessId)
    {
        HANDLE Process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, ProcessId);
        if (Process == nullptr)
            return {};

        wchar_t Path[32768] = {};
        DWORD Length = static_cast<DWORD>(std::size(Path));
        const BOOL Ok = QueryFullProcessImageNameW(Process, 0, Path, &Length);
        CloseHandle(Process);
        return Ok ? std::wstring(Path, Length) : std::wstring();
    }

    std::filesystem::path DotaCacheDirectory(const std::wstring& ImagePath)
    {
        if (ImagePath.empty())
            return {};

        const std::filesystem::path Exe(ImagePath);
        if (_wcsicmp(Exe.filename().c_str(), L"dota2.exe") != 0)
            return {};

        // ...\dota 2 beta\game\bin\win64\dota2.exe
        const std::filesystem::path Game = Exe.parent_path().parent_path().parent_path();
        if (_wcsicmp(Game.filename().c_str(), L"game") != 0)
            return {};

        return Game / L"dota";
    }

    std::filesystem::path SteamRootFromCacheDirectory(const std::filesystem::path& CacheDirectory)
    {
        // ...\Steam\steamapps\common\dota 2 beta\game\dota
        const std::filesystem::path SteamApps =
            CacheDirectory.parent_path().parent_path().parent_path().parent_path();
        if (_wcsicmp(SteamApps.filename().c_str(), L"steamapps") != 0)
            return {};

        return SteamApps.parent_path();
    }

    bool IsCacheFile(const std::filesystem::path& Path)
    {
        const std::wstring Name = Path.filename().wstring();
        return Name.rfind(L"cache_", 0) == 0 && Path.extension() == L".soc";
    }

    std::size_t PurgeCacheFiles(const std::filesystem::path& CacheDirectory)
    {
        std::error_code Error;
        if (!std::filesystem::is_directory(CacheDirectory, Error))
            return 0;

        std::vector<std::filesystem::path> Files;
        for (const auto& Entry : std::filesystem::directory_iterator(CacheDirectory, Error))
        {
            if (Error)
                break;

            std::error_code EntryError;
            if (Entry.is_regular_file(EntryError) && IsCacheFile(Entry.path()))
                Files.push_back(Entry.path());
        }

        std::size_t Removed = 0;
        for (const auto& File : Files)
        {
            std::error_code RemoveError;
            if (std::filesystem::remove(File, RemoveError))
                ++Removed;
        }

        return Removed;
    }

    bool ContainsFakeItemIds(const std::filesystem::path& File)
    {
        std::ifstream Input(File, std::ios::binary);
        if (!Input)
            return false;

        // Fake item ids are 0x7000000000000000 | def_index. Their decimal
        // representation starts with 8070450532247; real ids are much smaller.
        const std::string Data((std::istreambuf_iterator<char>(Input)),
                               std::istreambuf_iterator<char>());
        return Data.find("8070450532247") != std::string::npos;
    }

    void ClearFakeAcknowledgements(const std::filesystem::path& SteamRoot)
    {
        if (SteamRoot.empty())
            return;

        std::error_code Error;
        const std::filesystem::path UserData = SteamRoot / L"userdata";
        if (!std::filesystem::is_directory(UserData, Error))
            return;

        for (const auto& Account : std::filesystem::directory_iterator(UserData, Error))
        {
            if (Error)
                break;

            std::error_code AccountError;
            if (!Account.is_directory(AccountError))
                continue;

            const std::filesystem::path Acks =
                Account.path() / L"570" / L"remote" / L"item_clientacks.txt";
            std::error_code FileError;
            if (!std::filesystem::is_regular_file(Acks, FileError) || !ContainsFakeItemIds(Acks))
                continue;

            // This is only Valve's "item seen" cache. Dota recreates it on the
            // next launch; clearing it removes the fake ids without touching
            // the real inventory or any settings.
            std::ofstream Output(Acks, std::ios::binary | std::ios::trunc);
        }
    }

    int CleanupAfterProcess(DWORD ProcessId, const std::filesystem::path& CacheDirectory)
    {
        const std::wstring MutexName =
            L"Local\\AnchouseChangerCleanup_" + std::to_wstring(ProcessId);
        HANDLE Mutex = CreateMutexW(nullptr, TRUE, MutexName.c_str());
        if (Mutex != nullptr && GetLastError() == ERROR_ALREADY_EXISTS)
        {
            CloseHandle(Mutex);
            return 0;
        }

        HANDLE Process = OpenProcess(SYNCHRONIZE, FALSE, ProcessId);
        if (Process != nullptr)
        {
            WaitForSingleObject(Process, INFINITE);
            CloseHandle(Process);
        }
        else
        {
            // If the process cannot be opened, wait until its pid disappears.
            for (;;)
            {
                const std::vector<DWORD> Processes = FindProcesses(ProcessName);
                if (std::find(Processes.begin(), Processes.end(), ProcessId) == Processes.end())
                    break;
                Sleep(1000);
            }
        }

        // Do not touch the cache if the player has already started another
        // session. Purging a live session's disk cache would not help anyway.
        if (!FindProcesses(ProcessName).empty())
        {
            if (Mutex != nullptr)
                CloseHandle(Mutex);
            return 0;
        }

        PurgeCacheFiles(CacheDirectory);
        ClearFakeAcknowledgements(SteamRootFromCacheDirectory(CacheDirectory));
        if (Mutex != nullptr)
            CloseHandle(Mutex);
        return 0;
    }

    bool StartCleanupWatcher(DWORD ProcessId, const std::filesystem::path& CacheDirectory)
    {
        if (CacheDirectory.empty())
            return false;

        wchar_t LoaderPath[MAX_PATH] = {};
        const DWORD Length = GetModuleFileNameW(nullptr, LoaderPath, static_cast<DWORD>(std::size(LoaderPath)));
        if (Length == 0 || Length >= std::size(LoaderPath))
            return false;

        std::wstring Command = L"\"" + std::wstring(LoaderPath, Length) + L"\" --cleanup " +
                               std::to_wstring(ProcessId) + L" \"" + CacheDirectory.wstring() + L"\"";
        STARTUPINFOW Startup = {};
        Startup.cb = sizeof(Startup);
        Startup.dwFlags = STARTF_USESHOWWINDOW;
        Startup.wShowWindow = SW_HIDE;
        PROCESS_INFORMATION Info = {};

        DWORD Flags = CREATE_NO_WINDOW | CREATE_BREAKAWAY_FROM_JOB;
        BOOL Ok = CreateProcessW(LoaderPath, Command.data(), nullptr, nullptr, FALSE,
                                 Flags, nullptr, nullptr, &Startup, &Info);
        if (!Ok)
        {
            // Some launchers put the loader in a job that does not allow
            // breakaway. A normal hidden child still works there.
            Flags = CREATE_NO_WINDOW;
            Ok = CreateProcessW(LoaderPath, Command.data(), nullptr, nullptr, FALSE,
                                Flags, nullptr, nullptr, &Startup, &Info);
        }

        if (!Ok)
            return false;

        CloseHandle(Info.hThread);
        CloseHandle(Info.hProcess);
        return true;
    }

    bool HasVisibleWindow(DWORD ProcessId)
    {
        struct Context
        {
            DWORD ProcessId;
            bool Found;
        } Data = { ProcessId, false };

        EnumWindows([](HWND Window, LPARAM Param) -> BOOL
        {
            auto* Data = reinterpret_cast<Context*>(Param);
            DWORD Owner = 0;
            GetWindowThreadProcessId(Window, &Owner);
            if (Owner != Data->ProcessId || !IsWindowVisible(Window) || GetWindow(Window, GW_OWNER) != nullptr)
                return TRUE;

            wchar_t Title[256] = {};
            if (GetWindowTextW(Window, Title, static_cast<int>(std::size(Title))) == 0)
                return TRUE;

            Data->Found = true;
            return FALSE;
        }, reinterpret_cast<LPARAM>(&Data));

        return Data.Found;
    }

    bool EnableDebugPrivilege()
    {
        HANDLE Token = nullptr;
        if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &Token))
            return false;

        LUID Luid = {};
        if (!LookupPrivilegeValueW(nullptr, L"SeDebugPrivilege", &Luid))
        {
            CloseHandle(Token);
            return false;
        }

        TOKEN_PRIVILEGES Privileges = {};
        Privileges.PrivilegeCount = 1;
        Privileges.Privileges[0].Luid = Luid;
        Privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

        SetLastError(ERROR_SUCCESS);
        const BOOL Ok = AdjustTokenPrivileges(Token, FALSE, &Privileges, sizeof(Privileges), nullptr, nullptr);
        const DWORD Error = GetLastError();
        CloseHandle(Token);
        return Ok != FALSE && Error != ERROR_NOT_ALL_ASSIGNED;
    }

    std::wstring ResolveDllPath(const std::wstring& Requested, bool Explicit)
    {
        std::error_code Error;
        std::filesystem::path Path(Requested);

        if (!Explicit)
            Path = std::filesystem::path(ExecutableDirectory()) / DefaultDllName;

        if (Path.is_relative())
        {
            if (Explicit)
            {
                const std::filesystem::path BesideLoader = std::filesystem::path(ExecutableDirectory()) / Path;
                if (std::filesystem::exists(BesideLoader, Error))
                    Path = BesideLoader;
                else
                    Path = std::filesystem::absolute(Path, Error);
            }
            else
            {
                Path = std::filesystem::absolute(Path, Error);
            }
        }

        return Path.lexically_normal().wstring();
    }

    std::filesystem::path LoaderMarkerPath(const std::wstring& DllPath, DWORD TargetPid)
    {
        return std::filesystem::path(DllPath).parent_path() /
               (L"anchousechanger.loader." + std::to_wstring(TargetPid));
    }

    bool WriteLoaderMarker(const std::wstring& DllPath, DWORD TargetPid)
    {
        std::ofstream Marker(LoaderMarkerPath(DllPath, TargetPid), std::ios::binary | std::ios::trunc);
        if (!Marker)
            return false;

        Marker << "pid=" << GetCurrentProcessId() << "\n";
        Marker << "time=" << static_cast<unsigned long long>(std::time(nullptr)) << "\n";
        Marker.close();
        return !Marker.fail();
    }

    void RemoveLoaderMarker(const std::wstring& DllPath, DWORD TargetPid)
    {
        std::error_code Error;
        std::filesystem::remove(LoaderMarkerPath(DllPath, TargetPid), Error);
    }

    bool Inject(DWORD ProcessId, const std::wstring& DllPath)
    {
        constexpr DWORD Access = PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION |
                                 PROCESS_VM_WRITE | PROCESS_VM_READ;

        HANDLE Process = OpenProcess(Access, FALSE, ProcessId);
        if (Process == nullptr)
        {
            const DWORD Error = GetLastError();
            std::wcerr << L"[-] OpenProcess failed: " << Error;
            if (Error == ERROR_ACCESS_DENIED)
                std::wcerr << L" (access denied - run loader.exe as administrator)";
            std::wcerr << L"\n";
            return false;
        }

        BOOL Wow64 = FALSE;
        if (IsWow64Process(Process, &Wow64) && Wow64)
        {
            std::wcerr << L"[-] dota2.exe is 32-bit. Build and use an x64 loader.\n";
            CloseHandle(Process);
            return false;
        }

        const std::size_t Bytes = (DllPath.size() + 1) * sizeof(wchar_t);
        void* RemotePath = VirtualAllocEx(Process, nullptr, Bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
        if (RemotePath == nullptr)
        {
            std::wcerr << L"[-] VirtualAllocEx failed: " << GetLastError() << L"\n";
            CloseHandle(Process);
            return false;
        }

        if (!WriteProcessMemory(Process, RemotePath, DllPath.c_str(), Bytes, nullptr))
        {
            std::wcerr << L"[-] WriteProcessMemory failed: " << GetLastError() << L"\n";
            VirtualFreeEx(Process, RemotePath, 0, MEM_RELEASE);
            CloseHandle(Process);
            return false;
        }

        const HMODULE Kernel32 = GetModuleHandleW(L"kernel32.dll");
        const auto LoadLibrary = reinterpret_cast<LPTHREAD_START_ROUTINE>(
            Kernel32 ? GetProcAddress(Kernel32, "LoadLibraryW") : nullptr);
        if (LoadLibrary == nullptr)
        {
            std::wcerr << L"[-] Could not resolve LoadLibraryW.\n";
            VirtualFreeEx(Process, RemotePath, 0, MEM_RELEASE);
            CloseHandle(Process);
            return false;
        }

        HANDLE Thread = CreateRemoteThread(Process, nullptr, 0, LoadLibrary, RemotePath, 0, nullptr);
        if (Thread == nullptr)
        {
            std::wcerr << L"[-] CreateRemoteThread failed: " << GetLastError() << L"\n";
            VirtualFreeEx(Process, RemotePath, 0, MEM_RELEASE);
            CloseHandle(Process);
            return false;
        }

        const DWORD Wait = WaitForSingleObject(Thread, 30000);
        const bool Finished = Wait == WAIT_OBJECT_0;
        DWORD ExitCode = 0;
        if (Finished)
            GetExitCodeThread(Thread, &ExitCode);

        CloseHandle(Thread);
        if (Finished)
            VirtualFreeEx(Process, RemotePath, 0, MEM_RELEASE);
        CloseHandle(Process);

        if (!Finished)
        {
            // The remote thread may still be using the path, so leave the small
            // allocation in the target process instead of risking a crash.
            std::wcerr << L"[-] Timed out while waiting for the DLL to load.\n";
            return false;
        }

        if (ExitCode == 0)
        {
            std::wcerr << L"[-] LoadLibraryW returned NULL. The DLL failed to load.\n"
                          L"    Check that anchousechanger.log has no early errors and that the DLL architecture matches the game.\n";
            return false;
        }

        std::wcout << L"[+] Injected successfully. DLL base: 0x" << std::hex << ExitCode << std::dec << L"\n";
        return true;
    }

    void PrintUsage()
    {
        std::wcout <<
            L"anchousechanger loader\n"
            L"\n"
            L"Usage:\n"
            L"  loader.exe [options] [dll_path]\n"
            L"\n"
            L"Options:\n"
            L"  --launch, -l      Start Dota 2 through Steam if it is not running.\n"
            L"                    Close Dota first: the loader injects early so the\n"
            L"                    full catalog can replace the first SOCache subscription.\n"
            L"  --pid <pid>, -p   Inject into a specific process instead of finding dota2.exe.\n"
            L"  --dll <path>, -d  DLL to inject (default: anchousechanger.dll beside loader.exe).\n"
            L"  --help, -h        Show this help.\n"
            L"\n"
            L"Examples:\n"
            L"  loader.exe\n"
            L"  loader.exe --launch\n"
            L"  loader.exe -p 12345\n"
            L"  loader.exe D:\\tools\\anchousechanger.dll\n";
    }

    bool ParseUnsigned(const wchar_t* Text, DWORD& Value)
    {
        wchar_t* End = nullptr;
        const unsigned long Parsed = wcstoul(Text, &End, 10);
        if (End == Text || *End != L'\0' || Parsed == 0 || Parsed > 0xFFFFFFFFul)
            return false;
        Value = static_cast<DWORD>(Parsed);
        return true;
    }
}

int wmain(int argc, wchar_t** argv)
{
    // Internal hidden mode: wait for the game to exit, then remove the
    // persisted SOCache so a subsequent launch without the DLL starts from
    // the real inventory. This branch must run before DLL path validation.
    if (argc >= 2 && _wcsicmp(argv[1], L"--cleanup") == 0)
    {
        if (argc < 4)
            return 1;

        DWORD CleanupProcessId = 0;
        if (!ParseUnsigned(argv[2], CleanupProcessId))
            return 1;

        return CleanupAfterProcess(CleanupProcessId, std::filesystem::path(argv[3]));
    }

    SetConsoleOutputCP(CP_UTF8);
    SetConsoleTitleW(L"anchousechanger loader");

    bool Launch = false;
    bool ExplicitDll = false;
    DWORD ProcessId = 0;
    std::wstring DllPath;

    for (int i = 1; i < argc; ++i)
    {
        const std::wstring Arg = argv[i];
        if (Arg == L"--help" || Arg == L"-h")
        {
            PrintUsage();
            return 0;
        }
        if (Arg == L"--launch" || Arg == L"-l")
        {
            Launch = true;
            continue;
        }
        if (Arg == L"--pid" || Arg == L"-p")
        {
            if (i + 1 >= argc || !ParseUnsigned(argv[++i], ProcessId))
            {
                std::wcerr << L"[-] Invalid process id.\n";
                return 1;
            }
            continue;
        }
        if (Arg == L"--dll" || Arg == L"-d")
        {
            if (i + 1 >= argc)
            {
                std::wcerr << L"[-] Missing path after --dll.\n";
                return 1;
            }
            DllPath = argv[++i];
            ExplicitDll = true;
            continue;
        }
        if (!Arg.empty() && Arg[0] == L'-')
        {
            std::wcerr << L"[-] Unknown option: " << Arg << L"\n";
            PrintUsage();
            return 1;
        }
        if (ExplicitDll)
        {
            std::wcerr << L"[-] More than one DLL path was specified.\n";
            return 1;
        }

        DllPath = Arg;
        ExplicitDll = true;
    }

    if (DllPath.empty())
        DllPath = DefaultDllName;

    DllPath = ResolveDllPath(DllPath, ExplicitDll);
    std::error_code FileError;
    if (!std::filesystem::is_regular_file(DllPath, FileError))
    {
        std::wcerr << L"[-] DLL not found: " << DllPath << L"\n";
        return 2;
    }

    std::wcout << L"[*] DLL: " << DllPath << L"\n";

    if (ProcessId == 0)
    {
        std::vector<DWORD> Processes = FindProcesses(ProcessName);
        if (Processes.empty() && Launch)
        {
            std::wcout << L"[*] Dota 2 is not running, starting it through Steam...\n";
            const HINSTANCE Result = ShellExecuteW(nullptr, L"open", SteamLaunchUrl, nullptr, nullptr, SW_SHOWNORMAL);
            if (reinterpret_cast<std::intptr_t>(Result) <= 32)
            {
                std::wcerr << L"[-] Could not start Steam. Start Dota 2 manually and run the loader again.\n";
                return 2;
            }

            const auto Deadline = std::chrono::steady_clock::now() + std::chrono::minutes(3);
            while (std::chrono::steady_clock::now() < Deadline)
            {
                Sleep(500);
                Processes = FindProcesses(ProcessName);
                if (!Processes.empty())
                    break;
            }

            if (Processes.empty())
            {
                std::wcerr << L"[-] Dota 2 did not start within 3 minutes.\n";
                return 2;
            }

            std::wcout << L"[*] Waiting for the game modules...\n";
            if (!WaitForGameModules(Processes.front()))
            {
                std::wcerr << L"[-] Dota 2 did not finish loading its modules within 1 minute.\n";
                return 2;
            }

            // Do not wait for the main menu here. The client requests its real
            // SOCache as soon as the GC connects; injecting after that request
            // makes it impossible to replace the cache with the full catalog.
            // A short settle delay lets the UI/schema interfaces register while
            // still leaving the first cache subscription ahead of us.
            std::wcout << L"[*] Modules ready; injecting before the first SOCache subscription...\n";
            Sleep(1200);
        }

        if (Processes.empty())
        {
            std::wcerr << L"[-] Dota 2 is not running. Start the game, then run loader.exe again.\n"
                          L"    Tip: use --launch to start it through Steam automatically.\n";
            return 2;
        }

        if (Processes.size() > 1)
            std::wcout << L"[!] Found " << Processes.size() << L" dota2.exe processes, using pid " << Processes.front() << L".\n";

        ProcessId = Processes.front();
    }

    std::wcout << L"[*] Target process: " << ProcessId << L"\n";
    if (!EnableDebugPrivilege())
        std::wcout << L"[!] SeDebugPrivilege is not available. If injection fails, run loader.exe as administrator.\n";

    const std::wstring ImagePath = ProcessImagePath(ProcessId);
    const std::filesystem::path CacheDirectory = DotaCacheDirectory(ImagePath);
    if (CacheDirectory.empty())
    {
        std::wcout << L"[!] Could not locate the Dota SOCache directory; "
                      L"automatic cleanup after exit is disabled.\n";
    }
    else
    {
        const std::size_t Removed = PurgeCacheFiles(CacheDirectory);
        if (Removed > 0)
            std::wcout << L"[*] Removed " << Removed << L" stale SOCache file(s).\n";

        if (StartCleanupWatcher(ProcessId, CacheDirectory))
            std::wcout << L"[*] Automatic SOCache cleanup armed for process exit.\n";
        else
            std::wcout << L"[!] Could not start automatic SOCache cleanup.\n";
    }

    const bool MarkerWritten = WriteLoaderMarker(DllPath, ProcessId);
    if (!MarkerWritten)
        std::wcout << L"[!] Could not write loader marker; auto-grant will be disabled.\n";

    const bool Injected = Inject(ProcessId, DllPath);
    if (!Injected && MarkerWritten)
        RemoveLoaderMarker(DllPath, ProcessId);
    return Injected ? 0 : 3;
}
