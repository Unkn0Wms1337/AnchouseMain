#include "UnusualStore.h"

#include <map>
#include <vector>

namespace
{
    std::map<std::uint64_t, int> Effects;
    std::vector<UnusualStore::Listener> Listeners;
}

int UnusualStore::Get(std::uint64_t ItemId)
{
    auto Entry = Effects.find(ItemId);
    return Entry != Effects.end() ? Entry->second : 0;
}

void UnusualStore::Set(std::uint64_t ItemId, int EffectId)
{
    if (!ItemId || Get(ItemId) == EffectId)
        return;

    if (EffectId)
        Effects[ItemId] = EffectId;
    else
        Effects.erase(ItemId);

    for (Listener Callback : Listeners)
        Callback(ItemId, EffectId);
}

const std::map<std::uint64_t, int>& UnusualStore::All()
{
    return Effects;
}

void UnusualStore::Subscribe(Listener Callback)
{
    if (Callback)
        Listeners.push_back(Callback);
}
